import{R as i}from"./index-76fb7be0.js";import"./_commonjsHelpers-de833af9.js";var u=function(t){var s=t.label,l=t.varient,c=t.handleClick,a=t.isDisabled;return i.createElement("button",{type:"button",onClick:c,disabled:!!a,className:l+" "+(a==!0?"disabled-btn":"")},s)};const b={title:"Example/Button",component:u,parameters:{layout:"centered"},tags:["autodocs"]},e={args:{label:"Button",varient:"accent"}};var n,r,o;e.parameters={...e.parameters,docs:{...(n=e.parameters)==null?void 0:n.docs,source:{originalSource:`{
  args: {
    label: 'Button',
    varient: 'accent'
  }
}`,...(o=(r=e.parameters)==null?void 0:r.docs)==null?void 0:o.source}}};const v=["Primary"];export{e as Primary,v as __namedExportsOrder,b as default};
